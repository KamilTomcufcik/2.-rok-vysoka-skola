#include "a_train.h"
#include <stdio.h>

struct car* add_car(struct car* first,const char* target) {
    return NULL;
}

void print_train(struct car* first) {
}

void cancel_train(struct car* first) {
}


struct car* clear_train(struct car* first, const char* target) {
	return NULL;
}

